package com.fab.service;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fab.dao.DBOperations;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String admin_name = request.getParameter("admin_name");
		String admin_password = request.getParameter("admin_password");
		DBOperations dboperations=new DBOperations();
		/*if(admin_name.equals("gupta@gmail.com")&&admin_password.equals("1234")){
			RequestDispatcher rd;
			rd=request.getRequestDispatcher("file.html");
			rd.include(request, response);
		}*/
		if(dboperations.display(admin_name, admin_password)){
			RequestDispatcher rd;
			rd=request.getRequestDispatcher("/file.html");
			rd.include(request, response);

		}
		else{
			out.println("Sorry!!!not Found");
		}
		
	}
}

