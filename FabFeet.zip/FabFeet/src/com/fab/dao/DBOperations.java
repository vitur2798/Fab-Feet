package com.fab.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.fab.bean.Manager;
import com.fab.bean.Product;

public class DBOperations {
	SessionFactory sеssionFactory;
	Session session;
	Transaction tx;

	public DBOperations() {
		sеssionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
	}

	public void insert(Product product) {
		session = sеssionFactory.openSession();
		tx = session.beginTransaction();
		try {
			session.save(product);
			tx.commit();
			Query q = session.createQuery("FROM Product");
			List<Product> list = q.list();
			System.out.println("value inserted");
			System.out.println(list);
			session.close();
		} catch (Exception e) {
			System.out.println("error at insert" + e);
		}

	}

	public boolean display(String name,String password)
	{
		boolean result=false;
	List<Manager> list=null;
	session=sеssionFactory.openSession();
	tx=session.beginTransaction();
	try
	{
	Query query=session.createQuery("FROM Manager");
	list=query.list();
	while(list!=null){
		//System.out.println(list.get(1));
		if(list.get(1).equals(name) && list.get(2).equals(password)){
			session.close();
			result=true;
		}
	}
	}
	catch(Exception e)
	{
	result=false;
	}
	return result;
}
}
