package com.fab.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.fab.bean.CustomerLogin;
import com.fab.bean.Manager;
import com.fab.bean.Product;

public class DBOperations {
	SessionFactory sessionFactory;
	Session session;
	Transaction tx;

	public DBOperations() {
		sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
	}

	public void customer_insert(CustomerLogin customerlogin) {
		session = sessionFactory.openSession();
		tx = session.beginTransaction();
		try {
			session.saveOrUpdate(customerlogin);
			tx.commit();
			System.out.println("value inserted");
			session.close();
		} catch (Exception e) {
			System.out.println("error at insert" + e);
		}

	}

	public List<CustomerLogin> display(String customer_username,String customer_password)
	{
	List<CustomerLogin> list=null;
	session=sessionFactory.openSession();
	tx=session.beginTransaction();
	try
	{
	Query query=session.createQuery("FROM Customer");
	list=query.list();
	}
	catch(Exception e)
	{
	list=null;
	}
	return list;
}
}
