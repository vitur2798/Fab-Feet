package com.fab.service;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fab.bean.CustomerLogin;
import com.fab.dao.DBOperations;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String admin_email = request.getParameter("admin_email");
		String admin_pwd = request.getParameter("admin_pwd");
		
		String customer_username=request.getParameter("customer_username");
		String customer_password=request.getParameter("customer_password");
		DBOperations dboperations=new DBOperations();
		CustomerLogin customerlogin=new CustomerLogin();
		customerlogin.setCustomer_username(customer_username);
		customerlogin.setCustomer_password(customer_password);
		dboperations.customer_insert(customerlogin);
		
		out.print(dboperations.display(customer_username, customer_password));
		
		/*if(admin_email.equals("gupta@gmail.com")&&admin_pwd.equals("1234")){
			RequestDispatcher rd;
			rd=request.getRequestDispatcher("file.html");
			rd.include(request, response);
		}
		if(dboperations.display(admin_name, admin_password)){
			RequestDispatcher rd;
			rd=request.getRequestDispatcher("/file.html");
			rd.include(request, response);

		}
		else{
			out.println("Sorry!!!not Found");
		}*/
		doGet(request,response);
		
	}

}
